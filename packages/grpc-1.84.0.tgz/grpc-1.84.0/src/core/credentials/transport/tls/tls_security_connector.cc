//
//
// Copyright 2018 gRPC authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//

#include "src/core/credentials/transport/tls/tls_security_connector.h"

#include <grpc/grpc.h>
#include <grpc/grpc_security_constants.h>
#include <grpc/support/alloc.h>
#include <grpc/support/port_platform.h>
#include <grpc/support/string_util.h>
#include <string.h>

#include <cstddef>
#include <memory>
#include <optional>
#include <utility>
#include <vector>

#include "src/core/client_channel/client_channel_args.h"
#include "src/core/credentials/transport/tls/grpc_tls_certificate_selector.h"
#include "src/core/credentials/transport/tls/grpc_tls_certificate_verifier.h"
#include "src/core/credentials/transport/tls/grpc_tls_credentials_options.h"
#include "src/core/credentials/transport/tls/ssl_utils.h"
#include "src/core/credentials/transport/transport_credentials.h"
#include "src/core/handshaker/security/security_handshaker.h"
#include "src/core/lib/channel/channel_args.h"
#include "src/core/lib/iomgr/exec_ctx.h"
#include "src/core/lib/promise/promise.h"
#include "src/core/telemetry/metrics.h"
#include "src/core/transport/auth_context.h"
#include "src/core/tsi/ssl_transport_security.h"
#include "src/core/util/debug_location.h"
#include "src/core/util/grpc_check.h"
#include "src/core/util/host_port.h"
#include "src/core/util/status_helper.h"
#include "absl/functional/bind_front.h"
#include "absl/log/log.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/string_view.h"

namespace grpc_core {

namespace {

char* CopyCoreString(char* src, size_t length) {
  char* target = static_cast<char*>(gpr_malloc(length + 1));
  memcpy(target, src, length);
  target[length] = '\0';
  return target;
}

void PendingVerifierRequestInit(
    const char* target_name, tsi_peer peer,
    grpc_tls_custom_verification_check_request* request) {
  GRPC_CHECK_NE(request, nullptr);
  // The verifier holds a ref to the security connector, so it's fine to
  // directly point this to the name cached in the security connector.
  request->target_name = target_name;
  // TODO(ZhenLian): avoid the copy when the underlying core implementation used
  // the null-terminating string.
  bool has_common_name = false;
  bool has_peer_cert = false;
  bool has_peer_cert_full_chain = false;
  bool has_verified_root_cert_subject = false;
  bool has_negotiated_key_exchange_group = false;
  std::vector<char*> uri_names;
  std::vector<char*> dns_names;
  std::vector<char*> email_names;
  std::vector<char*> ip_names;
  for (size_t i = 0; i < peer.property_count; ++i) {
    const tsi_peer_property* prop = &peer.properties[i];
    if (prop->name == nullptr) continue;
    if (strcmp(prop->name, TSI_X509_SUBJECT_COMMON_NAME_PEER_PROPERTY) == 0) {
      request->peer_info.common_name =
          CopyCoreString(prop->value.data, prop->value.length);
      has_common_name = true;
    } else if (strcmp(prop->name, TSI_X509_PEM_CERT_PROPERTY) == 0) {
      request->peer_info.peer_cert =
          CopyCoreString(prop->value.data, prop->value.length);
      has_peer_cert = true;
    } else if (strcmp(prop->name, TSI_X509_PEM_CERT_CHAIN_PROPERTY) == 0) {
      request->peer_info.peer_cert_full_chain =
          CopyCoreString(prop->value.data, prop->value.length);
      has_peer_cert_full_chain = true;
    } else if (strcmp(prop->name, TSI_X509_URI_PEER_PROPERTY) == 0) {
      char* uri = CopyCoreString(prop->value.data, prop->value.length);
      uri_names.emplace_back(uri);
    } else if (strcmp(prop->name, TSI_X509_DNS_PEER_PROPERTY) == 0) {
      char* dns = CopyCoreString(prop->value.data, prop->value.length);
      dns_names.emplace_back(dns);
    } else if (strcmp(prop->name, TSI_X509_EMAIL_PEER_PROPERTY) == 0) {
      char* email = CopyCoreString(prop->value.data, prop->value.length);
      email_names.emplace_back(email);
    } else if (strcmp(prop->name, TSI_X509_IP_PEER_PROPERTY) == 0) {
      char* ip = CopyCoreString(prop->value.data, prop->value.length);
      ip_names.emplace_back(ip);
    } else if (strcmp(prop->name,
                      TSI_X509_VERIFIED_ROOT_CERT_SUBECT_PEER_PROPERTY) == 0) {
      request->peer_info.verified_root_cert_subject =
          CopyCoreString(prop->value.data, prop->value.length);
      has_verified_root_cert_subject = true;
    } else if (strcmp(prop->name, TSI_SSL_NEGOTIATED_KEY_EXCHANGE_GROUP) == 0) {
      request->peer_info.negotiated_key_exchange_group =
          CopyCoreString(prop->value.data, prop->value.length);
      has_negotiated_key_exchange_group = true;
    }
  }
  if (!has_common_name) {
    request->peer_info.common_name = nullptr;
  }
  if (!has_peer_cert) {
    request->peer_info.peer_cert = nullptr;
  }
  if (!has_peer_cert_full_chain) {
    request->peer_info.peer_cert_full_chain = nullptr;
  }
  if (!has_verified_root_cert_subject) {
    request->peer_info.verified_root_cert_subject = nullptr;
  }
  if (!has_negotiated_key_exchange_group) {
    request->peer_info.negotiated_key_exchange_group = nullptr;
  }
  request->peer_info.san_names.uri_names_size = uri_names.size();
  if (!uri_names.empty()) {
    request->peer_info.san_names.uri_names =
        new char*[request->peer_info.san_names.uri_names_size];
    for (size_t i = 0; i < request->peer_info.san_names.uri_names_size; ++i) {
      // We directly point the char* string stored in vector to the |request|.
      // That string will be released when the |request| is destroyed.
      request->peer_info.san_names.uri_names[i] = uri_names[i];
    }
  } else {
    request->peer_info.san_names.uri_names = nullptr;
  }
  request->peer_info.san_names.dns_names_size = dns_names.size();
  if (!dns_names.empty()) {
    request->peer_info.san_names.dns_names =
        new char*[request->peer_info.san_names.dns_names_size];
    for (size_t i = 0; i < request->peer_info.san_names.dns_names_size; ++i) {
      // We directly point the char* string stored in vector to the |request|.
      // That string will be released when the |request| is destroyed.
      request->peer_info.san_names.dns_names[i] = dns_names[i];
    }
  } else {
    request->peer_info.san_names.dns_names = nullptr;
  }
  request->peer_info.san_names.email_names_size = email_names.size();
  if (!email_names.empty()) {
    request->peer_info.san_names.email_names =
        new char*[request->peer_info.san_names.email_names_size];
    for (size_t i = 0; i < request->peer_info.san_names.email_names_size; ++i) {
      // We directly point the char* string stored in vector to the |request|.
      // That string will be released when the |request| is destroyed.
      request->peer_info.san_names.email_names[i] = email_names[i];
    }
  } else {
    request->peer_info.san_names.email_names = nullptr;
  }
  request->peer_info.san_names.ip_names_size = ip_names.size();
  if (!ip_names.empty()) {
    request->peer_info.san_names.ip_names =
        new char*[request->peer_info.san_names.ip_names_size];
    for (size_t i = 0; i < request->peer_info.san_names.ip_names_size; ++i) {
      // We directly point the char* string stored in vector to the |request|.
      // That string will be released when the |request| is destroyed.
      request->peer_info.san_names.ip_names[i] = ip_names[i];
    }
  } else {
    request->peer_info.san_names.ip_names = nullptr;
  }
}

void PendingVerifierRequestDestroy(
    grpc_tls_custom_verification_check_request* request) {
  GRPC_CHECK_NE(request, nullptr);
  if (request->peer_info.common_name != nullptr) {
    gpr_free(const_cast<char*>(request->peer_info.common_name));
  }
  if (request->peer_info.san_names.uri_names_size > 0) {
    for (size_t i = 0; i < request->peer_info.san_names.uri_names_size; ++i) {
      gpr_free(request->peer_info.san_names.uri_names[i]);
    }
    delete[] request->peer_info.san_names.uri_names;
  }
  if (request->peer_info.san_names.dns_names_size > 0) {
    for (size_t i = 0; i < request->peer_info.san_names.dns_names_size; ++i) {
      gpr_free(request->peer_info.san_names.dns_names[i]);
    }
    delete[] request->peer_info.san_names.dns_names;
  }
  if (request->peer_info.san_names.email_names_size > 0) {
    for (size_t i = 0; i < request->peer_info.san_names.email_names_size; ++i) {
      gpr_free(request->peer_info.san_names.email_names[i]);
    }
    delete[] request->peer_info.san_names.email_names;
  }
  if (request->peer_info.san_names.ip_names_size > 0) {
    for (size_t i = 0; i < request->peer_info.san_names.ip_names_size; ++i) {
      gpr_free(request->peer_info.san_names.ip_names[i]);
    }
    delete[] request->peer_info.san_names.ip_names;
  }
  if (request->peer_info.peer_cert != nullptr) {
    gpr_free(const_cast<char*>(request->peer_info.peer_cert));
  }
  if (request->peer_info.peer_cert_full_chain != nullptr) {
    gpr_free(const_cast<char*>(request->peer_info.peer_cert_full_chain));
  }
  if (request->peer_info.verified_root_cert_subject != nullptr) {
    gpr_free(const_cast<char*>(request->peer_info.verified_root_cert_subject));
  }
  if (request->peer_info.negotiated_key_exchange_group != nullptr) {
    gpr_free(
        const_cast<char*>(request->peer_info.negotiated_key_exchange_group));
  }
}
}  // namespace

// -------------------channel security connector-------------------
RefCountedPtr<grpc_channel_security_connector>
TlsChannelSecurityConnector::CreateTlsChannelSecurityConnector(
    RefCountedPtr<grpc_channel_credentials> channel_creds,
    RefCountedPtr<grpc_tls_credentials_options> options,
    RefCountedPtr<grpc_call_credentials> request_metadata_creds,
    const char* target_name, const char* overridden_target_name,
    tsi_ssl_session_cache* ssl_session_cache) {
  if (channel_creds == nullptr) {
    LOG(ERROR) << "channel_creds is nullptr in "
                  "TlsChannelSecurityConnectorCreate()";
    return nullptr;
  }
  if (options == nullptr) {
    LOG(ERROR) << "options is nullptr in "
                  "TlsChannelSecurityConnectorCreate()";
    return nullptr;
  }
  if (target_name == nullptr) {
    LOG(ERROR) << "target_name is nullptr in "
                  "TlsChannelSecurityConnectorCreate()";
    return nullptr;
  }
  return MakeRefCounted<TlsChannelSecurityConnector>(
      std::move(channel_creds), std::move(options),
      std::move(request_metadata_creds), target_name, overridden_target_name,
      ssl_session_cache);
}

TlsChannelSecurityConnector::TlsChannelSecurityConnector(
    RefCountedPtr<grpc_channel_credentials> channel_creds,
    RefCountedPtr<grpc_tls_credentials_options> options,
    RefCountedPtr<grpc_call_credentials> request_metadata_creds,
    const char* target_name, const char* overridden_target_name,
    tsi_ssl_session_cache* ssl_session_cache)
    : grpc_channel_security_connector(GRPC_SSL_URL_SCHEME,
                                      std::move(channel_creds),
                                      std::move(request_metadata_creds)),
      options_(std::move(options)),
      overridden_target_name_(
          overridden_target_name == nullptr ? "" : overridden_target_name),
      ssl_session_cache_(ssl_session_cache) {
  const std::string& tls_session_key_log_file_path =
      options_->tls_session_key_log_file_path();
  if (!tls_session_key_log_file_path.empty()) {
    tls_session_key_logger_ =
        tsi::TlsSessionKeyLoggerCache::Get(tls_session_key_log_file_path);
  }
  if (ssl_session_cache_ != nullptr) {
    tsi_ssl_session_cache_ref(ssl_session_cache_);
  }
  absl::string_view host;
  absl::string_view port;
  SplitHostPort(target_name, &host, &port);
  target_name_ = std::string(host);
  // Create a watcher.
  auto identity_watcher_ptr =
      std::make_unique<TlsChannelCertificateWatcher>(this);
  auto root_watcher_ptr = std::make_unique<TlsChannelCertificateWatcher>(this);
  root_certificate_watcher_ = root_watcher_ptr.get();
  identity_certificate_watcher_ = identity_watcher_ptr.get();
  bool watch_root_cert = options_->root_certificate_distributor() != nullptr;
  bool watch_identity_cert =
      options_->identity_certificate_distributor() != nullptr;
  std::optional<std::string> watched_root_cert_name;
  if (watch_root_cert) {
    watched_root_cert_name = options_->root_cert_name();
  }
  std::optional<std::string> watched_identity_cert_name;
  if (watch_identity_cert) {
    watched_identity_cert_name = options_->identity_cert_name();
  }
  // We will use the root certs stored in system default locations if not
  // watching root certs on the client side. We will handle this case
  // differently here, because "watching a default roots without the identity
  // certs" is a valid case(and hence we will need to call
  // OnCertificatesChanged), but it requires nothing from the provider, and
  // hence no need to register the watcher.
  if (!watch_root_cert && !watch_identity_cert) {
    root_certificate_watcher_->OnCertificatesChanged(nullptr, std::nullopt);
  } else {
    if (watch_root_cert) {
      options_->root_certificate_distributor()->WatchTlsCertificates(
          std::move(root_watcher_ptr), watched_root_cert_name,
          watched_identity_cert_name);
    }
    if (watch_identity_cert) {
      options_->identity_certificate_distributor()->WatchTlsCertificates(
          std::move(identity_watcher_ptr), watched_root_cert_name,
          watched_identity_cert_name);
    }
  }
}

TlsChannelSecurityConnector::~TlsChannelSecurityConnector() {
  if (ssl_session_cache_ != nullptr) {
    tsi_ssl_session_cache_unref(ssl_session_cache_);
  }
  // Cancel all the watchers.
  grpc_tls_certificate_distributor* root_distributor =
      options_->root_certificate_distributor();
  if (root_distributor != nullptr) {
    root_distributor->CancelTlsCertificatesWatch(root_certificate_watcher_);
  }
  grpc_tls_certificate_distributor* identity_distributor =
      options_->identity_certificate_distributor();
  if (identity_distributor != nullptr) {
    identity_distributor->CancelTlsCertificatesWatch(
        identity_certificate_watcher_);
  }
  if (client_handshaker_factory_ != nullptr) {
    tsi_ssl_client_handshaker_factory_unref(client_handshaker_factory_);
  }
}

void TlsChannelSecurityConnector::add_handshakers(
    const ChannelArgs& args, grpc_pollset_set* /*interested_parties*/,
    HandshakeManager* handshake_mgr) {
  MutexLock lock(&mu_);
  tsi_handshaker* tsi_hs = nullptr;
  if (client_handshaker_factory_ != nullptr) {
    // Instantiate TSI handshaker.
    const char* server_name_indication;
    if (options_->sni_override().has_value()) {
      if (options_->sni_override()->empty()) {
        server_name_indication = nullptr;
      } else {
        server_name_indication = options_->sni_override()->c_str();
      }
    } else {
      server_name_indication = overridden_target_name_.empty()
                                   ? target_name_.c_str()
                                   : overridden_target_name_.c_str();
    }
    auto stats_plugin_group =
        args.GetObject<GlobalStatsPluginRegistry::StatsPluginGroup>();
    RefCountedPtr<CollectionScope> collection_scope =
        stats_plugin_group != nullptr ? stats_plugin_group->GetCollectionScope()
                                      : nullptr;
    std::string backend_service(
        args.GetString(GRPC_ARG_BACKEND_SERVICE).value_or(""));
    std::string locality(args.GetString(GRPC_ARG_LB_LOCALITY).value_or(""));
    std::string target(args.GetString(GRPC_ARG_SERVER_URI).value_or(""));
    tsi_result result = tsi_ssl_client_handshaker_factory_create_handshaker(
        client_handshaker_factory_, server_name_indication,
        /*network_bio_buf_size=*/0,
        /*ssl_bio_buf_size=*/0,
        args.GetOwnedString(GRPC_ARG_TRANSPORT_PROTOCOLS),
        std::move(collection_scope), std::move(target), std::move(locality),
        std::move(backend_service), &tsi_hs);
    if (result != TSI_OK) {
      LOG(ERROR) << "Handshaker creation failed with error "
                 << tsi_result_to_string(result);
    }
  }
  // If tsi_hs is null, this will add a failing handshaker.
  handshake_mgr->Add(SecurityHandshakerCreate(tsi_hs, this, args));
}

void TlsChannelSecurityConnector::check_peer(
    tsi_peer peer, grpc_endpoint* /*ep*/, const ChannelArgs& /*args*/,
    RefCountedPtr<grpc_auth_context>* auth_context,
    grpc_closure* on_peer_checked) {
  const char* target_name = overridden_target_name_.empty()
                                ? target_name_.c_str()
                                : overridden_target_name_.c_str();
  grpc_error_handle error = grpc_ssl_check_alpn(&peer);
  if (!error.ok()) {
    ExecCtx::Run(DEBUG_LOCATION, on_peer_checked, error);
    tsi_peer_destruct(&peer);
    return;
  }
  *auth_context =
      grpc_ssl_peer_to_auth_context(&peer, GRPC_TLS_TRANSPORT_SECURITY_TYPE);
  GRPC_CHECK_NE(options_->certificate_verifier(), nullptr);
  auto* pending_request = new ChannelPendingVerifierRequest(
      RefAsSubclass<TlsChannelSecurityConnector>(), on_peer_checked, peer,
      target_name);
  {
    MutexLock lock(&verifier_request_map_mu_);
    pending_verifier_requests_.emplace(on_peer_checked, pending_request);
  }
  pending_request->Start();
}

void TlsChannelSecurityConnector::cancel_check_peer(
    grpc_closure* on_peer_checked, grpc_error_handle /*error*/) {
  auto* verifier = options_->certificate_verifier();
  if (verifier != nullptr) {
    grpc_tls_custom_verification_check_request* pending_verifier_request =
        nullptr;
    {
      MutexLock lock(&verifier_request_map_mu_);
      auto it = pending_verifier_requests_.find(on_peer_checked);
      if (it != pending_verifier_requests_.end()) {
        pending_verifier_request = it->second->request();
      } else {
        VLOG(2) << "TlsChannelSecurityConnector::cancel_check_peer: no "
                   "corresponding pending request found";
      }
    }
    if (pending_verifier_request != nullptr) {
      verifier->Cancel(pending_verifier_request);
    }
  }
}

int TlsChannelSecurityConnector::cmp(
    const grpc_security_connector* other_sc) const {
  auto* other = reinterpret_cast<const TlsChannelSecurityConnector*>(other_sc);
  int c = channel_security_connector_cmp(other);
  if (c != 0) return c;
  c = grpc_ssl_cmp_target_name(
      target_name_.c_str(), other->target_name_.c_str(),
      overridden_target_name_.c_str(), other->overridden_target_name_.c_str());
  if (c != 0) return c;
  return 0;
}

ArenaPromise<absl::Status> TlsChannelSecurityConnector::CheckCallHost(
    absl::string_view host, grpc_auth_context* auth_context) {
  if (options_->check_call_host()) {
    return Immediate(SslCheckCallHost(host, target_name_.c_str(),
                                      overridden_target_name_.c_str(),
                                      auth_context));
  }
  return ImmediateOkStatus();
}

void TlsChannelSecurityConnector::TlsChannelCertificateWatcher::
    OnCertificatesChanged(
        std::shared_ptr<tsi::RootCertInfo> root_certs,
        std::optional<KeyCertPairsOrSelector> key_cert_pairs_or_selector) {
  GRPC_CHECK_NE(security_connector_, nullptr);
  MutexLock lock(&security_connector_->mu_);
  if (root_certs != nullptr) {
    security_connector_->root_cert_info_ = std::move(root_certs);
  }
  if (key_cert_pairs_or_selector.has_value()) {
    security_connector_->key_cert_pairs_or_selector_ =
        std::move(key_cert_pairs_or_selector);
  }
  const bool root_ready =
      security_connector_->options_->root_certificate_distributor() ==
          nullptr ||
      security_connector_->root_cert_info_ != nullptr;
  const bool identity_ready =
      security_connector_->options_->identity_certificate_distributor() ==
          nullptr ||
      security_connector_->key_cert_pairs_or_selector_.has_value();
  if (root_ready && identity_ready) {
    if (security_connector_->UpdateHandshakerFactoryLocked() !=
        GRPC_SECURITY_OK) {
      LOG(ERROR) << "Update handshaker factory failed.";
    }
  }
}

// TODO(ZhenLian): implement the logic to signal waiting handshakers once
// BlockOnInitialCredentialHandshaker is implemented.
void TlsChannelSecurityConnector::TlsChannelCertificateWatcher::OnError(
    grpc_error_handle root_cert_error, grpc_error_handle identity_cert_error) {
  if (!root_cert_error.ok()) {
    LOG(ERROR) << "TlsChannelCertificateWatcher getting root_cert_error: "
               << StatusToString(root_cert_error);
  }
  if (!identity_cert_error.ok()) {
    LOG(ERROR) << "TlsChannelCertificateWatcher getting identity_cert_error: "
               << StatusToString(identity_cert_error);
  }
}

TlsChannelSecurityConnector::ChannelPendingVerifierRequest::
    ChannelPendingVerifierRequest(
        RefCountedPtr<TlsChannelSecurityConnector> security_connector,
        grpc_closure* on_peer_checked, tsi_peer peer, const char* target_name)
    : security_connector_(std::move(security_connector)),
      on_peer_checked_(on_peer_checked) {
  PendingVerifierRequestInit(target_name, peer, &request_);
  tsi_peer_destruct(&peer);
}

TlsChannelSecurityConnector::ChannelPendingVerifierRequest::
    ~ChannelPendingVerifierRequest() {
  PendingVerifierRequestDestroy(&request_);
}

void TlsChannelSecurityConnector::ChannelPendingVerifierRequest::Start() {
  absl::Status sync_status;
  grpc_tls_certificate_verifier* verifier =
      security_connector_->options_->certificate_verifier();
  bool is_done = verifier->Verify(
      &request_,
      absl::bind_front(&ChannelPendingVerifierRequest::OnVerifyDone, this,
                       true),
      &sync_status);
  if (is_done) {
    OnVerifyDone(false, sync_status);
  }
}

void TlsChannelSecurityConnector::ChannelPendingVerifierRequest::OnVerifyDone(
    bool run_callback_inline, absl::Status status) {
  {
    MutexLock lock(&security_connector_->verifier_request_map_mu_);
    security_connector_->pending_verifier_requests_.erase(on_peer_checked_);
  }
  grpc_error_handle error;
  if (!status.ok()) {
    error = GRPC_ERROR_CREATE(
        absl::StrCat("Custom verification check failed with error: ",
                     status.ToString())
            .c_str());
  }
  if (run_callback_inline) {
    Closure::Run(DEBUG_LOCATION, on_peer_checked_, error);
  } else {
    ExecCtx::Run(DEBUG_LOCATION, on_peer_checked_, error);
  }
  delete this;
}

// TODO(ZhenLian): implement the logic to signal waiting handshakers once
// BlockOnInitialCredentialHandshaker is implemented.
grpc_security_status
TlsChannelSecurityConnector::UpdateHandshakerFactoryLocked() {
  bool skip_server_certificate_verification = !options_->verify_server_cert();
  // Free the client handshaker factory if exists.
  if (client_handshaker_factory_ != nullptr) {
    tsi_ssl_client_handshaker_factory_unref(client_handshaker_factory_);
  }
  const PemKeyCertPair* pem_key_cert_pair = nullptr;
  if (key_cert_pairs_or_selector_.has_value()) {
    Match(
        *key_cert_pairs_or_selector_,
        [&pem_key_cert_pair](const PemKeyCertPairList& pem_key_cert_pairs) {
          pem_key_cert_pair =
              pem_key_cert_pairs.empty() ? nullptr : &pem_key_cert_pairs[0];
        },
        // This is not expected to happen and we do nothing here.
        [](const std::shared_ptr<CertificateSelector>&) {});
  }
  bool use_default_roots = options_->root_certificate_distributor() == nullptr;
  return grpc_ssl_tsi_client_handshaker_factory_init(
      pem_key_cert_pair, use_default_roots ? nullptr : root_cert_info_,
      skip_server_certificate_verification,
      grpc_get_tsi_tls_version(options_->min_tls_version()),
      grpc_get_tsi_tls_version(options_->max_tls_version()), ssl_session_cache_,
      tls_session_key_logger_.get(), options_->crl_directory().c_str(),
      options_->crl_provider(), options_->key_exchange_groups(),
      &client_handshaker_factory_);
}

// -------------------server security connector-------------------
RefCountedPtr<grpc_server_security_connector>
TlsServerSecurityConnector::CreateTlsServerSecurityConnector(
    RefCountedPtr<grpc_server_credentials> server_creds,
    RefCountedPtr<grpc_tls_credentials_options> options) {
  if (server_creds == nullptr) {
    LOG(ERROR) << "server_creds is nullptr in "
                  "TlsServerSecurityConnectorCreate()";
    return nullptr;
  }
  if (options == nullptr) {
    LOG(ERROR) << "options is nullptr in "
                  "TlsServerSecurityConnectorCreate()";
    return nullptr;
  }
  return MakeRefCounted<TlsServerSecurityConnector>(std::move(server_creds),
                                                    std::move(options));
}

TlsServerSecurityConnector::TlsServerSecurityConnector(
    RefCountedPtr<grpc_server_credentials> server_creds,
    RefCountedPtr<grpc_tls_credentials_options> options)
    : grpc_server_security_connector(GRPC_SSL_URL_SCHEME,
                                     std::move(server_creds)),
      options_(std::move(options)) {
  const std::string& tls_session_key_log_file_path =
      options_->tls_session_key_log_file_path();
  if (!tls_session_key_log_file_path.empty()) {
    tls_session_key_logger_ =
        tsi::TlsSessionKeyLoggerCache::Get(tls_session_key_log_file_path);
  }
  // Create a watcher.
  auto root_watcher_ptr = std::make_unique<TlsServerCertificateWatcher>(this);
  auto identity_watcher_ptr =
      std::make_unique<TlsServerCertificateWatcher>(this);
  root_certificate_watcher_ = root_watcher_ptr.get();
  identity_certificate_watcher_ = identity_watcher_ptr.get();
  bool watch_root_cert = options_->root_certificate_distributor() != nullptr;
  bool watch_identity_cert =
      options_->identity_certificate_distributor() != nullptr;
  std::optional<std::string> watched_root_cert_name;
  if (watch_root_cert) {
    watched_root_cert_name = options_->root_cert_name();
  }
  std::optional<std::string> watched_identity_cert_name;
  if (watch_identity_cert) {
    watched_identity_cert_name = options_->identity_cert_name();
  }
  // Register the watcher with the distributor.
  if (watch_root_cert) {
    options_->root_certificate_distributor()->WatchTlsCertificates(
        std::move(root_watcher_ptr), watched_root_cert_name,
        watched_identity_cert_name);
  }
  if (watch_identity_cert) {
    options_->identity_certificate_distributor()->WatchTlsCertificates(
        std::move(identity_watcher_ptr), watched_root_cert_name,
        watched_identity_cert_name);
  }
}

TlsServerSecurityConnector::~TlsServerSecurityConnector() {
  // Cancel all the watchers.
  grpc_tls_certificate_distributor* root_distributor =
      options_->root_certificate_distributor();
  if (root_distributor != nullptr) {
    root_distributor->CancelTlsCertificatesWatch(root_certificate_watcher_);
  }
  grpc_tls_certificate_distributor* identity_distributor =
      options_->identity_certificate_distributor();
  if (identity_distributor != nullptr) {
    identity_distributor->CancelTlsCertificatesWatch(
        identity_certificate_watcher_);
  }
  if (server_handshaker_factory_ != nullptr) {
    tsi_ssl_server_handshaker_factory_unref(server_handshaker_factory_);
  }
}

void TlsServerSecurityConnector::add_handshakers(
    const ChannelArgs& args, grpc_pollset_set* /*interested_parties*/,
    HandshakeManager* handshake_mgr) {
  MutexLock lock(&mu_);
  tsi_handshaker* tsi_hs = nullptr;
  if (server_handshaker_factory_ != nullptr) {
    auto stats_plugin_group =
        args.GetObject<GlobalStatsPluginRegistry::StatsPluginGroup>();
    RefCountedPtr<CollectionScope> collection_scope =
        stats_plugin_group != nullptr ? stats_plugin_group->GetCollectionScope()
                                      : nullptr;
    // Instantiate TSI handshaker.
    tsi_result result = tsi_ssl_server_handshaker_factory_create_handshaker(
        server_handshaker_factory_, /*network_bio_buf_size=*/0,
        /*ssl_bio_buf_size=*/0, std::move(collection_scope), &tsi_hs);
    if (result != TSI_OK) {
      LOG(ERROR) << "Handshaker creation failed with error "
                 << tsi_result_to_string(result);
    }
  }
  // If tsi_hs is null, this will add a failing handshaker.
  handshake_mgr->Add(SecurityHandshakerCreate(tsi_hs, this, args));
}

void TlsServerSecurityConnector::check_peer(
    tsi_peer peer, grpc_endpoint* /*ep*/, const ChannelArgs& /*args*/,
    RefCountedPtr<grpc_auth_context>* auth_context,
    grpc_closure* on_peer_checked) {
  grpc_error_handle error = grpc_ssl_check_alpn(&peer);
  if (!error.ok()) {
    ExecCtx::Run(DEBUG_LOCATION, on_peer_checked, error);
    tsi_peer_destruct(&peer);
    return;
  }
  *auth_context =
      grpc_ssl_peer_to_auth_context(&peer, GRPC_TLS_TRANSPORT_SECURITY_TYPE);
  if (options_->certificate_verifier() != nullptr) {
    auto* pending_request = new ServerPendingVerifierRequest(
        RefAsSubclass<TlsServerSecurityConnector>(), on_peer_checked, peer);
    {
      MutexLock lock(&verifier_request_map_mu_);
      pending_verifier_requests_.emplace(on_peer_checked, pending_request);
    }
    pending_request->Start();
  } else {
    tsi_peer_destruct(&peer);
    ExecCtx::Run(DEBUG_LOCATION, on_peer_checked, error);
  }
}

void TlsServerSecurityConnector::cancel_check_peer(
    grpc_closure* on_peer_checked, grpc_error_handle /*error*/) {
  auto* verifier = options_->certificate_verifier();
  if (verifier != nullptr) {
    grpc_tls_custom_verification_check_request* pending_verifier_request =
        nullptr;
    {
      MutexLock lock(&verifier_request_map_mu_);
      auto it = pending_verifier_requests_.find(on_peer_checked);
      if (it != pending_verifier_requests_.end()) {
        pending_verifier_request = it->second->request();
      } else {
        LOG(INFO) << "TlsServerSecurityConnector::cancel_check_peer: no "
                     "corresponding pending request found";
      }
    }
    if (pending_verifier_request != nullptr) {
      verifier->Cancel(pending_verifier_request);
    }
  }
}

int TlsServerSecurityConnector::cmp(
    const grpc_security_connector* other_sc) const {
  auto* other = reinterpret_cast<const TlsServerSecurityConnector*>(other_sc);
  int c = server_security_connector_cmp(other);
  if (c != 0) return c;
  return 0;
}

void TlsServerSecurityConnector::TlsServerCertificateWatcher::
    OnCertificatesChanged(
        std::shared_ptr<tsi::RootCertInfo> roots,
        std::optional<KeyCertPairsOrSelector> key_cert_pairs_or_selector) {
  GRPC_CHECK_NE(security_connector_, nullptr);
  MutexLock lock(&security_connector_->mu_);
  if (roots != nullptr) {
    security_connector_->root_cert_info_ = std::move(roots);
  }
  if (key_cert_pairs_or_selector.has_value()) {
    security_connector_->key_cert_pairs_or_selector_ =
        std::move(key_cert_pairs_or_selector);
  }
  bool root_being_watched =
      security_connector_->options_->root_certificate_distributor() != nullptr;
  bool root_has_value = security_connector_->root_cert_info_ != nullptr;
  bool identity_being_watched =
      security_connector_->options_->identity_certificate_distributor() !=
      nullptr;
  bool identity_has_value =
      security_connector_->key_cert_pairs_or_selector_.has_value();
  if ((root_being_watched && root_has_value && identity_being_watched &&
       identity_has_value) ||
      (root_being_watched && root_has_value && !identity_being_watched) ||
      (!root_being_watched && identity_being_watched && identity_has_value)) {
    if (security_connector_->UpdateHandshakerFactoryLocked() !=
        GRPC_SECURITY_OK) {
      LOG(ERROR) << "Update handshaker factory failed.";
    }
  }
}

// TODO(ZhenLian): implement the logic to signal waiting handshakers once
// BlockOnInitialCredentialHandshaker is implemented.
void TlsServerSecurityConnector::TlsServerCertificateWatcher::OnError(
    grpc_error_handle root_cert_error, grpc_error_handle identity_cert_error) {
  if (!root_cert_error.ok()) {
    LOG(ERROR) << "TlsServerCertificateWatcher getting root_cert_error: "
               << StatusToString(root_cert_error);
  }
  if (!identity_cert_error.ok()) {
    LOG(ERROR) << "TlsServerCertificateWatcher getting identity_cert_error: "
               << StatusToString(identity_cert_error);
  }
}

TlsServerSecurityConnector::ServerPendingVerifierRequest::
    ServerPendingVerifierRequest(
        RefCountedPtr<TlsServerSecurityConnector> security_connector,
        grpc_closure* on_peer_checked, tsi_peer peer)
    : security_connector_(std::move(security_connector)),
      on_peer_checked_(on_peer_checked) {
  PendingVerifierRequestInit(nullptr, peer, &request_);
  tsi_peer_destruct(&peer);
}

TlsServerSecurityConnector::ServerPendingVerifierRequest::
    ~ServerPendingVerifierRequest() {
  PendingVerifierRequestDestroy(&request_);
}

void TlsServerSecurityConnector::ServerPendingVerifierRequest::Start() {
  absl::Status sync_status;
  grpc_tls_certificate_verifier* verifier =
      security_connector_->options_->certificate_verifier();
  bool is_done = verifier->Verify(
      &request_,
      absl::bind_front(&ServerPendingVerifierRequest::OnVerifyDone, this, true),
      &sync_status);
  if (is_done) {
    OnVerifyDone(false, sync_status);
  }
}

void TlsServerSecurityConnector::ServerPendingVerifierRequest::OnVerifyDone(
    bool run_callback_inline, absl::Status status) {
  {
    MutexLock lock(&security_connector_->verifier_request_map_mu_);
    security_connector_->pending_verifier_requests_.erase(on_peer_checked_);
  }
  grpc_error_handle error;
  if (!status.ok()) {
    error = GRPC_ERROR_CREATE(
        absl::StrCat("Custom verification check failed with error: ",
                     status.ToString())
            .c_str());
  }
  if (run_callback_inline) {
    Closure::Run(DEBUG_LOCATION, on_peer_checked_, error);
  } else {
    ExecCtx::Run(DEBUG_LOCATION, on_peer_checked_, error);
  }
  delete this;
}

// TODO(ZhenLian): implement the logic to signal waiting handshakers once
// BlockOnInitialCredentialHandshaker is implemented.
grpc_security_status
TlsServerSecurityConnector::UpdateHandshakerFactoryLocked() {
  // Free the server handshaker factory if exists.
  if (server_handshaker_factory_ != nullptr) {
    tsi_ssl_server_handshaker_factory_unref(server_handshaker_factory_);
  }
  // The identity certs on the server side shouldn't be empty.
  GRPC_CHECK(key_cert_pairs_or_selector_.has_value());
  GRPC_CHECK(!IsKeyCertPairsOrSelectorEmpty(*key_cert_pairs_or_selector_));
  return grpc_ssl_tsi_server_handshaker_factory_init(
      *key_cert_pairs_or_selector_, root_cert_info_,
      options_->cert_request_type(),
      grpc_get_tsi_tls_version(options_->min_tls_version()),
      grpc_get_tsi_tls_version(options_->max_tls_version()),
      tls_session_key_logger_.get(), options_->crl_directory().c_str(),
      options_->send_client_ca_list(), options_->crl_provider(),
      options_->key_exchange_groups(), &server_handshaker_factory_);
}

}  // namespace grpc_core
