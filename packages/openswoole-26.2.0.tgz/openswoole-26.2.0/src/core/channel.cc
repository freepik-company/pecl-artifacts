/*
  +----------------------------------------------------------------------+
  | OpenSwoole                                                          |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.0 of the Apache license,    |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.apache.org/licenses/LICENSE-2.0.html                      |
  | If you did not receive a copy of the Apache2.0 license and are unable|
  | to obtain it through the world-wide-web, please send a note to       |
  | hello@swoole.co.uk so we can mail you a copy immediately.            |
  +----------------------------------------------------------------------+
  | @author   Tianfeng Han  <mikan.tenny@gmail.com>                      |
  +----------------------------------------------------------------------+
*/

#include "openswoole.h"
#include "openswoole_memory.h"
#include "openswoole_channel.h"
#include "openswoole_lock.h"
#include "openswoole_pipe.h"

namespace openswoole {

#define OSW_CHANNEL_MIN_MEM (1024 * 64)

struct ChannelSlice {
    int length;
    char data[0];
};

Channel *Channel::make(size_t size, size_t maxlen, int flags) {
    assert(size >= maxlen);
    void *mem;

    // use shared memory
    if (flags & OSW_CHAN_SHM) {
        /**
         * overflow space
         */
        mem = osw_shm_malloc(size + sizeof(Channel) + maxlen + sizeof(ChannelSlice));
    } else {
        mem = osw_malloc(size + sizeof(Channel) + maxlen + sizeof(ChannelSlice));
    }

    if (mem == nullptr) {
        openswoole_warning("alloc(%ld) failed", size);
        return nullptr;
    }

    Channel *object = (Channel *) mem;
    mem = (char *) mem + sizeof(Channel);

    *object = {};

    // overflow space
    object->size = size;
    object->mem = mem;
    object->maxlen = maxlen;
    object->flags = flags;

    // use lock
    if (flags & OSW_CHAN_LOCK) {
        // init lock
        object->lock = new Mutex(Mutex::PROCESS_SHARED);
    }
    // use notify
    if (flags & OSW_CHAN_NOTIFY) {
        object->notify_pipe = new Pipe(true);
        if (!object->notify_pipe->ready()) {
            openswoole_warning("notify_fd init failed");
            delete object->notify_pipe;
            return nullptr;
        }
    }

    return object;
}

/**
 * push data(no lock)
 */
int Channel::in(const void *in_data, int data_length) {
    assert(data_length <= maxlen);
    if (full()) {
        return OSW_ERR;
    }
    ChannelSlice *item;
    int msize = sizeof(item->length) + data_length;

    if (tail < head) {
        // no enough memory space
        if ((head - tail) < msize) {
            return OSW_ERR;
        }
        item = (ChannelSlice *) ((char *) mem + tail);
        tail += msize;
    } else {
        item = (ChannelSlice *) ((char *) mem + tail);
        tail += msize;
        if (tail >= (off_t) size) {
            tail = 0;
            tail_tag = 1 - tail_tag;
        }
    }
    num++;
    bytes += data_length;
    item->length = data_length;
    memcpy(item->data, in_data, data_length);
    return OSW_OK;
}

/**
 * pop data(no lock)
 */
int Channel::out(void *out_buf, int buffer_length) {
    if (empty()) {
        return OSW_ERR;
    }

    ChannelSlice *item = (ChannelSlice *) ((char *) mem + head);
    assert(buffer_length >= item->length);
    memcpy(out_buf, item->data, item->length);
    head += (item->length + sizeof(item->length));
    if (head >= (off_t) size) {
        head = 0;
        head_tag = 1 - head_tag;
    }
    num--;
    bytes -= item->length;
    return item->length;
}

/**
 * peek data
 */
int Channel::peek(void *out, int buffer_length) {
    if (empty()) {
        return OSW_ERR;
    }

    int length;
    lock->lock();
    ChannelSlice *item = (ChannelSlice *) ((char *) mem + head);
    assert(buffer_length >= item->length);
    memcpy(out, item->data, item->length);
    length = item->length;
    lock->unlock();

    return length;
}

/**
 * wait notify
 */
int Channel::wait() {
    assert(flags & OSW_CHAN_NOTIFY);
    uint64_t value;
    return notify_pipe->read(&value, sizeof(value));
}

/**
 * new data coming, notify to customer
 */
int Channel::notify() {
    assert(flags & OSW_CHAN_NOTIFY);
    uint64_t value = 1;
    return notify_pipe->write(&value, sizeof(value));
}

/**
 * push data (lock)
 */
int Channel::push(const void *in_data, int data_length) {
    assert(flags & OSW_CHAN_LOCK);
    lock->lock();
    int ret = in(in_data, data_length);
    lock->unlock();
    return ret;
}

/**
 * free channel
 */
void Channel::destroy() {
    if (flags & OSW_CHAN_LOCK) {
        delete lock;
    }
    if (flags & OSW_CHAN_NOTIFY) {
        notify_pipe->close();
        delete notify_pipe;
    }
    if (flags & OSW_CHAN_SHM) {
        osw_shm_free(this);
    } else {
        osw_free(this);
    }
}

/**
 * pop data (lock)
 */
int Channel::pop(void *out_buf, int buffer_length) {
    assert(flags & OSW_CHAN_LOCK);
    lock->lock();
    int n = out(out_buf, buffer_length);
    lock->unlock();
    return n;
}

void Channel::print() {
    printf("Channel\n{\n"
           "    off_t head = %ld;\n"
           "    off_t tail = %ld;\n"
           "    size_t size = %ld;\n"
           "    char head_tag = %d;\n"
           "    char tail_tag = %d;\n"
           "    int num = %d;\n"
           "    size_t bytes = %ld;\n"
           "    int flag = %d;\n"
           "    int maxlen = %d;\n"
           "\n}\n",
           (long) head,
           (long) tail,
           size,
           tail_tag,
           head_tag,
           num,
           bytes,
           flags,
           maxlen);
}

}  // namespace openswoole
