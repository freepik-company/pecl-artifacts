/*
  +----------------------------------------------------------------------+
  | Open Swoole                                                          |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.0 of the Apache license,    |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.apache.org/licenses/LICENSE-2.0.html                      |
  | If you did not receive a copy of the Apache2.0 license and are unable|
  | to obtain it through the world-wide-web, please send a note to       |
  | hello@swoole.co.uk so we can mail you a copy immediately.            |
  +----------------------------------------------------------------------+
  | @author   Tianfeng Han  <mikan.tenny@gmail.com>                      |
  +----------------------------------------------------------------------+
*/

#include "test_core.h"
#include "openswoole_pipe.h"

using namespace openswoole;

TEST(reactor, create) {
    openswoole_event_init(0);

    Reactor *reactor = SwooleTG.reactor;

    ASSERT_EQ(reactor->max_event_num, OSW_REACTOR_MAXEVENTS);

    ASSERT_TRUE(reactor->running);
    ASSERT_NE(reactor->write, nullptr);
    ASSERT_NE(reactor->close, nullptr);
    ASSERT_EQ(reactor->defer_tasks, nullptr);
    ASSERT_NE(reactor->default_write_handler, nullptr);

    /**
     * coroutine socket reactor
     */
    ASSERT_NE(reactor->read_handler[Reactor::get_fd_type(OSW_FD_CORO_SOCKET | OSW_EVENT_READ)], nullptr);
    ASSERT_NE(reactor->write_handler[Reactor::get_fd_type(OSW_FD_CORO_SOCKET | OSW_EVENT_WRITE)], nullptr);
    ASSERT_NE(reactor->error_handler[Reactor::get_fd_type(OSW_FD_CORO_SOCKET | OSW_EVENT_ERROR)], nullptr);

    /**
     * system reactor
     */
    ASSERT_NE(reactor->read_handler[Reactor::get_fd_type(OSW_FD_CORO_POLL | OSW_EVENT_READ)], nullptr);
    ASSERT_NE(reactor->write_handler[Reactor::get_fd_type(OSW_FD_CORO_POLL | OSW_EVENT_WRITE)], nullptr);
    ASSERT_NE(reactor->error_handler[Reactor::get_fd_type(OSW_FD_CORO_POLL | OSW_EVENT_ERROR)], nullptr);

    ASSERT_NE(reactor->read_handler[Reactor::get_fd_type(OSW_FD_CORO_EVENT | OSW_EVENT_READ)], nullptr);
    ASSERT_NE(reactor->write_handler[Reactor::get_fd_type(OSW_FD_CORO_EVENT | OSW_EVENT_WRITE)], nullptr);
    ASSERT_NE(reactor->error_handler[Reactor::get_fd_type(OSW_FD_CORO_EVENT | OSW_EVENT_ERROR)], nullptr);

    ASSERT_NE(reactor->read_handler[Reactor::get_fd_type(OSW_FD_AIO | OSW_EVENT_READ)], nullptr);

    openswoole_event_free();
}

TEST(reactor, set_handler) {
    Reactor reactor;

    reactor.set_handler(OSW_EVENT_READ, (ReactorHandler) 0x1);
    ASSERT_EQ(reactor.read_handler[Reactor::get_fd_type(OSW_EVENT_READ)], (ReactorHandler) 0x1);

    reactor.set_handler(OSW_EVENT_WRITE, (ReactorHandler) 0x2);
    ASSERT_EQ(reactor.write_handler[Reactor::get_fd_type(OSW_EVENT_WRITE)], (ReactorHandler) 0x2);

    reactor.set_handler(OSW_EVENT_ERROR, (ReactorHandler) 0x3);
    ASSERT_EQ(reactor.error_handler[Reactor::get_fd_type(OSW_EVENT_ERROR)], (ReactorHandler) 0x3);
}

TEST(reactor, wait) {
    int ret;
    UnixSocket p(true, SOCK_DGRAM);
    ASSERT_TRUE(p.ready());

    ret = openswoole_event_init(OSW_EVENTLOOP_WAIT_EXIT);
    ASSERT_EQ(ret, OSW_OK);
    ASSERT_NE(SwooleTG.reactor, nullptr);

    openswoole_event_set_handler(OSW_FD_PIPE | OSW_EVENT_READ, [](Reactor *reactor, Event *ev) -> int {
        char buffer[16];

        ssize_t n = read(ev->fd, buffer, sizeof(buffer));
        EXPECT_EQ(sizeof("hello world"), n);
        EXPECT_STREQ("hello world", buffer);
        reactor->del(ev->socket);

        return OSW_OK;
    });

    ret = openswoole_event_add(p.get_socket(false), OSW_EVENT_READ);
    ASSERT_EQ(ret, OSW_OK);

    ret = p.write((void *) OSW_STRS("hello world"));
    ASSERT_EQ(ret, sizeof("hello world"));

    ret = openswoole_event_wait();
    ASSERT_EQ(ret, OSW_OK);
    ASSERT_EQ(SwooleTG.reactor, nullptr);
}

TEST(reactor, write) {
    int ret;
    UnixSocket p(true, SOCK_DGRAM);
    ASSERT_TRUE(p.ready());

    ret = openswoole_event_init(OSW_EVENTLOOP_WAIT_EXIT);
    ASSERT_EQ(ret, OSW_OK);
    ASSERT_NE(SwooleTG.reactor, nullptr);

    openswoole_event_set_handler(OSW_FD_PIPE | OSW_EVENT_READ, [](Reactor *reactor, Event *ev) -> int {
        char buffer[16];

        ssize_t n = read(ev->fd, buffer, sizeof(buffer));
        EXPECT_EQ(sizeof("hello world"), n);
        EXPECT_STREQ("hello world", buffer);
        reactor->del(ev->socket);

        return OSW_OK;
    });

    ret = openswoole_event_add(p.get_socket(false), OSW_EVENT_READ);
    ASSERT_EQ(ret, OSW_OK);

    ret = openswoole_event_write(p.get_socket(true), (void *) OSW_STRS("hello world"));
    ASSERT_EQ(ret, sizeof("hello world"));

    ret = openswoole_event_wait();
    ASSERT_EQ(ret, OSW_OK);
    ASSERT_EQ(SwooleTG.reactor, nullptr);
}

static const char *pkt = "hello world\r\n";

static void reactor_test_func(Reactor *reactor) {
    Pipe p(true);
    ASSERT_TRUE(p.ready());

    reactor->set_handler(OSW_FD_PIPE | OSW_EVENT_READ, [](Reactor *reactor, Event *event) -> int {
        char buf[1024];
        size_t l = strlen(pkt);
        size_t n = read(event->fd, buf, sizeof(buf));
        EXPECT_EQ(n, l);
        buf[n] = 0;
        EXPECT_EQ(std::string(buf, n), std::string(pkt));
        reactor->del(event->socket);

        return OSW_OK;
    });
    reactor->set_handler(OSW_FD_PIPE | OSW_EVENT_WRITE, [](Reactor *reactor, Event *event) -> int {
        size_t l = strlen(pkt);
        EXPECT_EQ(write(event->fd, pkt, l), l);
        reactor->del(event->socket);

        return OSW_OK;
    });
    reactor->add(p.get_socket(false), OSW_EVENT_READ);
    reactor->add(p.get_socket(true), OSW_EVENT_WRITE);
    reactor->wait(nullptr);
}

TEST(reactor, poll) {
    Reactor reactor(1024, Reactor::TYPE_POLL);
    reactor.wait_exit = true;
    reactor_test_func(&reactor);
}

TEST(reactor, select) {
    Reactor reactor(1024, Reactor::TYPE_SELECT);
    reactor.wait_exit = true;
    reactor_test_func(&reactor);
}

TEST(reactor, add_or_update) {
    int ret;
    UnixSocket p(true, SOCK_DGRAM);
    ASSERT_TRUE(p.ready());

    ret = openswoole_event_init(OSW_EVENTLOOP_WAIT_EXIT);
    ASSERT_EQ(ret, OSW_OK);
    ASSERT_NE(SwooleTG.reactor, nullptr);

    ret = openswoole_event_add_or_update(p.get_socket(false), OSW_EVENT_READ);
    ASSERT_EQ(ret, OSW_OK);
    ASSERT_TRUE(p.get_socket(false)->events & OSW_EVENT_READ);

    ret = openswoole_event_add_or_update(p.get_socket(false), OSW_EVENT_WRITE);
    ASSERT_EQ(ret, OSW_OK);
    ASSERT_TRUE(p.get_socket(false)->events & OSW_EVENT_READ);
    ASSERT_TRUE(p.get_socket(false)->events & OSW_EVENT_WRITE);

    openswoole_event_free();
}
