/*
  +----------------------------------------------------------------------+
  | Open Swoole                                                          |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.0 of the Apache license,    |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.apache.org/licenses/LICENSE-2.0.html                      |
  | If you did not receive a copy of the Apache2.0 license and are unable|
  | to obtain it through the world-wide-web, please send a note to       |
  | hello@swoole.co.uk so we can mail you a copy immediately.            |
  +----------------------------------------------------------------------+
  | @author   Tianfeng Han  <mikan.tenny@gmail.com>                      |
  +----------------------------------------------------------------------+
*/

#include "test_core.h"
#include "openswoole_server.h"

using namespace std;
using namespace openswoole::network;

TEST(stream, send) {
    swServer serv(swoole::Server::MODE_BASE);
    serv.worker_num = 1;
    int ori_log_level = osw_logger()->get_level();
    osw_logger()->set_level(OSW_LOG_ERROR);

    swListenPort *port = serv.add_port(OSW_SOCK_TCP, TEST_HOST, TEST_PORT);
    if (!port) {
        openswoole_warning("listen failed, [error=%d]", openswoole_get_last_error());
        exit(2);
    }

    port->open_length_check = true;
    Stream::set_protocol(&port->protocol);

    mutex lock;
    lock.lock();

    char buf[65536];
    ASSERT_EQ(openswoole_random_bytes(buf, sizeof(buf)), sizeof(buf));

    ASSERT_EQ(serv.create(), OSW_OK);

    std::thread t1([&]() {
        openswoole_signal_block_all();

        lock.lock();

        openswoole_event_init(OSW_EVENTLOOP_WAIT_EXIT);

        // bad request
        auto stream0 = Stream::create(TEST_TMP_FILE, 0, OSW_SOCK_UNIX_STREAM);
        ASSERT_EQ(stream0, nullptr);

        // bad request
        auto stream1 = Stream::create(TEST_HOST, 39999, OSW_SOCK_TCP);
        ASSERT_TRUE(stream1);
        stream1->response = [](Stream *stream, const char *data, uint32_t length) {
            EXPECT_EQ(data, nullptr);
            EXPECT_EQ(stream->errCode, ECONNREFUSED);
        };
        ASSERT_EQ(stream1->send(buf, sizeof(buf)), OSW_OK);

        // success requset
        auto stream2 = Stream::create(TEST_HOST, TEST_PORT, OSW_SOCK_TCP);
        ASSERT_TRUE(stream2);
        stream2->private_data = new string(buf, sizeof(buf));
        stream2->response = [](Stream *stream, const char *data, uint32_t length) {
            string *buf = (string *) stream->private_data;
            string pkt = string("Server: ") + *buf;
            EXPECT_EQ(string(data, length), pkt);
            delete buf;
        };
        ASSERT_EQ(stream2->send(buf, sizeof(buf)), OSW_OK);

        openswoole_event_wait();

        kill(getpid(), SIGTERM);
    });

    serv.onWorkerStart = [&lock](swServer *serv, int worker_id) { lock.unlock(); };

    serv.onReceive = [&buf](swServer *serv, swRecvData *req) -> int {
        string req_body(req->data + 4, req->info.len - 4);

        EXPECT_EQ(string(buf, sizeof(buf)), req_body);

        string pkt = string("Server: ") + req_body;
        int packed_len = htonl(pkt.length());

        EXPECT_TRUE(serv->send(req->info.fd, &packed_len, sizeof(packed_len)));
        EXPECT_TRUE(serv->send(req->info.fd, pkt.c_str(), pkt.length()));

        // end stream
        packed_len = htonl(0);
        EXPECT_TRUE(serv->send(req->info.fd, &packed_len, sizeof(packed_len)));

        return OSW_OK;
    };

    serv.start();
    t1.join();

    osw_logger()->set_level(ori_log_level);
}
