/*
  +----------------------------------------------------------------------+
  | Open Swoole                                                          |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.0 of the Apache license,    |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.apache.org/licenses/LICENSE-2.0.html                      |
  | If you did not receive a copy of the Apache2.0 license and are unable|
  | to obtain it through the world-wide-web, please send a note to       |
  | hello@swoole.co.uk so we can mail you a copy immediately.            |
  +----------------------------------------------------------------------+
  | @author   Tianfeng Han  <mikan.tenny@gmail.com>                      |
  +----------------------------------------------------------------------+
*/

#include "test_core.h"

#include "openswoole_server.h"
#include "openswoole_memory.h"
#include "openswoole_signal.h"
#include "openswoole_lock.h"

using namespace std;
using namespace openswoole;

TEST(server, create_pipe_buffers) {
    int ret;
    Server serv(Server::MODE_PROCESS);
    serv.create();

    ret = serv.create_pipe_buffers();
    ASSERT_EQ(0, ret);
    ASSERT_NE(nullptr, serv.pipe_buffers);
    for (uint32_t i = 0; i < serv.reactor_num; i++) {
        ASSERT_NE(nullptr, serv.pipe_buffers[i]);
    }
}

TEST(server, schedule) {
    int ret;
    Server serv(Server::MODE_PROCESS);
    serv.worker_num = 6;
    serv.dispatch_mode = Server::DISPATCH_IDLE_WORKER;
    ret = serv.create();
    ASSERT_EQ(OSW_OK, ret);

    for (uint32_t i = 0; i < serv.worker_num; i++) {
        serv.workers[i].status = OSW_WORKER_BUSY;
    }

    std::set<int> _worker_id_set;

    for (uint32_t i = 0; i < serv.worker_num; i++) {
        auto worker_id = serv.schedule_worker(i * 13, nullptr);
        _worker_id_set.insert(worker_id);
    }
    ASSERT_EQ(_worker_id_set.size(), serv.worker_num);

    for (uint32_t i = 1; i < serv.worker_num - 1; i++) {
        serv.workers[i].status = OSW_WORKER_IDLE;
    }

    _worker_id_set.clear();
    for (uint32_t i = 0; i < serv.worker_num; i++) {
        auto worker_id = serv.schedule_worker(i * 13, nullptr);
        _worker_id_set.insert(worker_id);
    }
    ASSERT_EQ(_worker_id_set.size(), serv.worker_num - 2);
}

static const char *packet = "hello world\n";

TEST(server, base) {
    Server serv(Server::MODE_BASE);
    serv.worker_num = 1;

    osw_logger()->set_level(OSW_LOG_WARNING);

    swListenPort *port = serv.add_port(OSW_SOCK_TCP, TEST_HOST, 0);
    ASSERT_TRUE(port);

    mutex lock;
    lock.lock();

    ASSERT_EQ(serv.create(), OSW_OK);

    std::thread t1([&]() {
        openswoole_signal_block_all();

        lock.lock();

        swoole::network::SyncClient c(OSW_SOCK_TCP);
        c.connect(TEST_HOST, port->port);
        c.send(packet, strlen(packet));
        char buf[1024];
        c.recv(buf, sizeof(buf));
        c.close();

        kill(getpid(), SIGTERM);
    });

    serv.onWorkerStart = [&lock](swServer *serv, int worker_id) { lock.unlock(); };

    serv.onReceive = [](swServer *serv, swRecvData *req) -> int {
        EXPECT_EQ(string(req->data, req->info.len), string(packet));

        string resp = string("Server: ") + string(packet);
        serv->send(req->info.fd, resp.c_str(), resp.length());

        return OSW_OK;
    };

    serv.start();
    t1.join();
}

TEST(server, process) {
    Server serv(Server::MODE_PROCESS);
    serv.worker_num = 1;

    SwooleG.running = 1;

    osw_logger()->set_level(OSW_LOG_WARNING);

    Mutex *lock = new Mutex(Mutex::PROCESS_SHARED);
    lock->lock();

    ListenPort *port = serv.add_port(OSW_SOCK_TCP, TEST_HOST, 0);
    if (!port) {
        openswoole_warning("listen failed, [error=%d]", openswoole_get_last_error());
        exit(2);
    }

    ASSERT_EQ(serv.create(), OSW_OK);

    serv.onStart = [&lock](swServer *serv) {
        thread t1([=]() {
            openswoole_signal_block_all();

            lock->lock();

            swListenPort *port = serv->get_primary_port();

            swoole::network::SyncClient c(OSW_SOCK_TCP);
            c.connect(TEST_HOST, port->port);
            c.send(packet, strlen(packet));
            char buf[1024];
            c.recv(buf, sizeof(buf));
            c.close();

            kill(serv->gs->master_pid, SIGTERM);
        });
        t1.detach();
    };

    serv.onWorkerStart = [&lock](swServer *serv, int worker_id) { lock->unlock(); };

    serv.onReceive = [](swServer *serv, swRecvData *req) -> int {
        EXPECT_EQ(string(req->data, req->info.len), string(packet));

        string resp = string("Server: ") + string(packet);
        serv->send(req->info.fd, resp.c_str(), resp.length());

        return OSW_OK;
    };

    ASSERT_EQ(serv.start(), 0);

    delete lock;
}

#ifdef OSW_USE_OPENSSL
TEST(server, ssl) {
    Server serv(Server::MODE_PROCESS);
    serv.worker_num = 1;

    SwooleG.running = 1;

    osw_logger()->set_level(OSW_LOG_WARNING);

    Mutex *lock = new Mutex(Mutex::PROCESS_SHARED);
    lock->lock();

    ListenPort *port = serv.add_port((enum swSocketType)(OSW_SOCK_TCP | OSW_SOCK_SSL), TEST_HOST, 0);
    if (!port) {
        openswoole_warning("listen failed, [error=%d]", openswoole_get_last_error());
        exit(2);
    }

    port->ssl_set_cert_file(test::get_root_path() + "/tests/include/ssl_certs/server.crt");
    port->ssl_set_key_file(test::get_root_path() + "/tests/include/ssl_certs/server.key");
    port->ssl_init();

    ASSERT_EQ(serv.create(), OSW_OK);

    serv.onStart = [&lock](Server *serv) {
        thread t1([=]() {
            openswoole_signal_block_all();

            lock->lock();

            ListenPort *port = serv->get_primary_port();

            EXPECT_EQ(port->ssl, 1);
            EXPECT_EQ(openswoole_ssl_is_thread_safety(), true);

            swoole::network::SyncClient c(OSW_SOCK_TCP);
            c.connect(TEST_HOST, port->port);
            c.enable_ssl_encrypt();
            c.send(packet, strlen(packet));
            char buf[1024];
            c.recv(buf, sizeof(buf));
            c.close();

            kill(serv->gs->master_pid, SIGTERM);
        });
        t1.detach();
    };

    serv.onWorkerStart = [&lock](Server *serv, int worker_id) { lock->unlock(); };

    serv.onReceive = [](Server *serv, RecvData *req) -> int {
        EXPECT_EQ(string(req->data, req->info.len), string(packet));

        string resp = string("Server: ") + string(packet);
        serv->send(req->info.fd, resp.c_str(), resp.length());

        return OSW_OK;
    };

    ASSERT_EQ(serv.start(), 0);

    delete lock;
}

TEST(server, dtls) {
    Server serv(Server::MODE_BASE);
    serv.worker_num = 1;

    SwooleG.running = 1;

    osw_logger()->set_level(OSW_LOG_WARNING);

    Mutex *lock = new Mutex(Mutex::PROCESS_SHARED);
    lock->lock();

    ListenPort *port = serv.add_port((enum swSocketType)(OSW_SOCK_UDP | OSW_SOCK_SSL), TEST_HOST, 0);
    if (!port) {
        openswoole_warning("listen failed, [error=%d]", openswoole_get_last_error());
        exit(2);
    }

    port->ssl_set_cert_file(test::get_root_path() + "/tests/include/ssl_certs/server.crt");
    port->ssl_set_key_file(test::get_root_path() + "/tests/include/ssl_certs/server.key");
    port->ssl_init();

    ASSERT_EQ(serv.create(), OSW_OK);

    serv.onStart = [&lock](Server *serv) {
        thread t1([=]() {
            openswoole_signal_block_all();

            lock->lock();

            ListenPort *port = serv->get_primary_port();

            EXPECT_EQ(port->ssl, 1);

            swoole::network::SyncClient c(OSW_SOCK_UDP);
            c.connect(TEST_HOST, port->port);
            c.enable_ssl_encrypt();
            c.send(packet, strlen(packet));
            char buf[1024];
            c.recv(buf, sizeof(buf));
            c.close();

            kill(serv->gs->master_pid, SIGTERM);
        });
        t1.detach();
    };

    serv.onWorkerStart = [&lock](Server *serv, int worker_id) { lock->unlock(); };

    serv.onReceive = [](Server *serv, RecvData *req) -> int {
        EXPECT_EQ(string(req->data, req->info.len), string(packet));

        string resp = string("Server: ") + string(packet);
        serv->send(req->info.fd, resp.c_str(), resp.length());

        return OSW_OK;
    };

    ASSERT_EQ(serv.start(), 0);

    delete lock;
}
#endif

TEST(server, task_worker) {
    Server serv;
    serv.worker_num = 1;
    serv.task_worker_num = 1;

    ListenPort *port = serv.add_port(OSW_SOCK_TCP, TEST_HOST, 0);
    if (!port) {
        openswoole_warning("listen failed, [error=%d]", openswoole_get_last_error());
        exit(2);
    }

    serv.onTask = [](swServer *serv, swEventData *task) -> int {
        EXPECT_EQ(string(task->data, task->info.len), string(packet));
        serv->gs->task_workers.running = 0;
        return 0;
    };

    ASSERT_EQ(serv.create(), OSW_OK);
    ASSERT_EQ(serv.create_task_workers(), OSW_OK);

    thread t1([&serv]() {
        serv.gs->task_workers.running = 1;
        serv.gs->task_workers.main_loop(&serv.gs->task_workers, &serv.gs->task_workers.workers[0]);
    });

    usleep(10000);

    EventData buf;
    memset(&buf.info, 0, sizeof(buf.info));

    OSW_TASK_TYPE(&buf) |= OSW_TASK_NOREPLY;
    buf.info.len = strlen(packet);
    memcpy(buf.data, packet, strlen(packet));

    int _dst_worker_id = 0;

    ASSERT_GE(serv.gs->task_workers.dispatch(&buf, &_dst_worker_id), 0);

    t1.join();
    serv.gs->task_workers.destroy();
}

TEST(server, max_connection) {
    Server serv;

    serv.set_max_connection(0);
    ASSERT_EQ(serv.get_max_connection(), OSW_MIN(OSW_MAX_CONNECTION, SwooleG.max_sockets));

    serv.set_max_connection(SwooleG.max_sockets + 13);
    ASSERT_EQ(serv.get_max_connection(), SwooleG.max_sockets);

    serv.set_max_connection(SwooleG.max_sockets - 13);
    ASSERT_EQ(serv.get_max_connection(), SwooleG.max_sockets - 13);

    uint32_t last_value = serv.get_max_connection();

    serv.create();

    serv.set_max_connection(100);
    ASSERT_EQ(serv.get_max_connection(), last_value);
}

TEST(server, min_connection) {
    Server serv;

    serv.task_worker_num = 14;
    serv.worker_num = 5;

    serv.add_port(OSW_SOCK_TCP, TEST_HOST, 0);

    serv.set_max_connection(15);
    serv.create();
    ASSERT_EQ(serv.get_max_connection(), SwooleG.max_sockets);
}

TEST(server, worker_num) {
    Server serv;

    serv.worker_num = OSW_CPU_NUM * OSW_MAX_WORKER_NCPU + 99;
    serv.task_worker_num = OSW_CPU_NUM * OSW_MAX_WORKER_NCPU + 99;
    serv.create();

    ASSERT_EQ(serv.worker_num, OSW_CPU_NUM * OSW_MAX_WORKER_NCPU);
    ASSERT_EQ(serv.task_worker_num, OSW_CPU_NUM * OSW_MAX_WORKER_NCPU);
}

TEST(server, reactor_num_base) {
    Server serv(Server::MODE_BASE);
    serv.reactor_num = OSW_CPU_NUM * OSW_MAX_THREAD_NCPU + 99;
    serv.create();

    ASSERT_EQ(serv.reactor_num, serv.worker_num);
}

TEST(server, reactor_num_large) {
    Server serv(Server::MODE_PROCESS);
    serv.worker_num = OSW_CPU_NUM * OSW_MAX_WORKER_NCPU;
    serv.reactor_num = OSW_CPU_NUM * OSW_MAX_THREAD_NCPU + 99;
    serv.create();

    ASSERT_EQ(serv.reactor_num, OSW_CPU_NUM * OSW_MAX_THREAD_NCPU);
}

TEST(server, reactor_num_large2) {
    Server serv(Server::MODE_PROCESS);
    serv.reactor_num = OSW_CPU_NUM * OSW_MAX_THREAD_NCPU + 99;
    serv.create();

    ASSERT_EQ(serv.reactor_num, serv.worker_num);
}

TEST(server, reactor_num_zero) {
    Server serv;
    serv.reactor_num = 0;
    serv.create();

    ASSERT_EQ(serv.reactor_num, OSW_CPU_NUM);
}
