--TEST--
openswoole_client_sync: connect 1 - 2
--SKIPIF--
<?php require  __DIR__ . '/../include/skipif.inc'; ?>
--FILE--
<?php declare(strict_types = 1);
require __DIR__ . '/../include/bootstrap.php';

killself_in_syncmode(1000, SIGTERM);

$cli = new \openswoole_client(SWOOLE_SOCK_TCP, OPENSWOOLE_SOCK_SYNC);
$r = $cli->connect(MYSQL_SERVER_HOST, MYSQL_SERVER_PORT);
Assert::assert($r);
$cli->close();
echo "SUCCESS";
?>
--EXPECT--
SUCCESS
