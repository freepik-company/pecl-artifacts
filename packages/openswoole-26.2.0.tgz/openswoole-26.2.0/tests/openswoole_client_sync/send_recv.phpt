--TEST--
openswoole_client_sync: send & recv
--SKIPIF--
<?php require __DIR__ . '/../include/skipif.inc'; ?>
--FILE--
<?php declare(strict_types = 1);
require __DIR__ . '/../include/bootstrap.php';
$pm = new ProcessManager;
$pm->parentFunc = function () use ($pm) {
    $cli = new openswoole_client(SWOOLE_SOCK_TCP, OPENSWOOLE_SOCK_SYNC);
    Assert::assert($cli->connect('127.0.0.1', $pm->getFreePort()));
    $request = "GET / HTTP/1.1\r\n\r\n";
    Assert::same($cli->send($request), strlen($request));
    usleep(100 * 1000);
    $response = $cli->recv();
    Assert::assert($response && substr($response, 0, 4) === 'HTTP');
    echo "SUCCESS\n";
    $pm->kill();
};
$pm->childFunc = function () use ($pm) {
    $http = new openswoole_http_server('127.0.0.1', $pm->getFreePort(), SWOOLE_BASE);
    $http->set(['worker_num' => 1, 'log_file' => '/dev/null']);
    $http->on('workerStart', function () use ($pm) {
        $pm->wakeup();
    });
    $http->on('request', function (openswoole_http_request $request, openswoole_http_response $response) {
        $response->end('OK');
    });
    $http->start();
};
$pm->childFirst();
$pm->run();
?>
--EXPECT--
SUCCESS
