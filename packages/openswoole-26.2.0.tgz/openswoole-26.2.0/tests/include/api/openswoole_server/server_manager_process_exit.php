<?php

require_once __DIR__ . "/../../../include/bootstrap.php";


if (pcntl_fork() === 0) {
    suicide(1000);
    exit();
}


if (pcntl_fork() === 0) {
    suicide(1000);
    exit();
}


if (pcntl_fork() === 0) {
    suicide(1000);


    $cli = new openswoole_client(SWOOLE_SOCK_TCP, true);

    /** @noinspection PhpVoidFunctionResultUsedInspection */
    assert($cli->set([
        "socket_buffer_size" => 1024,
    ]));

    $cli->on("connect", function(openswoole_client $cli) {
        openswoole_timer_clear($cli->timeo_id);
        Assert::true($cli->isConnected());
        $cli->send(str_repeat("\0", 1024));
    });

    $cli->on("receive", function(openswoole_client $cli, $data){
        $recv_len = strlen($data);
        debug_log("receive: len $recv_len");
        $cli->send(str_repeat("\0", $recv_len));
    });

    $cli->on("error", function(openswoole_client $cli) {
        openswoole_timer_clear($cli->timeo_id);
        debug_log("error");
    });

    $cli->on("close", function(openswoole_client $cli) {
        openswoole_timer_clear($cli->timeo_id);
        debug_log("close");
    });

    $cli->connect(TCP_SERVER_HOST, TCP_SERVER_PORT);
    $cli->timeo_id = openswoole_timer_after(1000, function() use($cli) {
        debug_log("connect timeout");
        $cli->close();
        Assert::false($cli->isConnected());
    });
    exit();
}

(new TcpServer())->start();

class TcpServer
{
    /**
     * @var \openswoole_server
     */
    public $swooleServer;

    public function __construct()
    {
        $this->swooleServer = new \openswoole_server(TCP_SERVER_HOST, TCP_SERVER_PORT, SWOOLE_PROCESS, SWOOLE_SOCK_TCP);
        $this->swooleServer->set([
            "output_buffer_size" => 1024 * 1024 * 1024, // 输出限制
            "max_connection" => 10240,
            "pipe_buffer_size" => 1024 * 1024 * 1024,
            'daemonize' => 0,
            'worker_num' => 2,
            'max_request' => 100000,
            'reactor_num' => 1,
            // 'package_max_length' => 1024 * 1024 * 2
        ]);
    }

    public function start()
    {
        $this->swooleServer->on('start', [$this, 'onStart']);
        $this->swooleServer->on('shutdown', [$this, 'onShutdown']);

        $this->swooleServer->on('workerStart', [$this, 'onWorkerStart']);
        $this->swooleServer->on('workerStop', [$this, 'onWorkerStop']);
        $this->swooleServer->on('workerError', [$this, 'onWorkerError']);

        $this->swooleServer->on('connect', [$this, 'onConnect']);
        $this->swooleServer->on('receive', [$this, 'onReceive']);

        $this->swooleServer->on('close', [$this, 'onClose']);

        $this->swooleServer->start();
    }

    public function onConnect()
    {
        debug_log("connecting ......");
    }

    public function onClose()
    {
        debug_log("closing .....");
    }

    public function onStart(openswoole_server $swooleServer)
    {
        debug_log("openswoole_server starting .....");
    }

    public function onShutdown(openswoole_server $swooleServer)
    {
        debug_log("openswoole_server shutdown .....");
    }

    public function onWorkerStart(openswoole_server $swooleServer, $workerId)
    {
        debug_log("worker #$workerId starting .....");
    }

    public function onWorkerStop(openswoole_server $swooleServer, $workerId)
    {
        debug_log("worker #$workerId stopping ....");
    }

    public function onWorkerError(openswoole_server $swooleServer, $workerId, $workerPid, $exitCode, $sigNo)
    {
        debug_log("worker error happening [workerId=$workerId, workerPid=$workerPid, exitCode=$exitCode, signalNo=$sigNo]...");
    }

    public function onReceive(openswoole_server $swooleServer, $fd, $fromId, $data)
    {
        $recv_len = strlen($data);
        debug_log("receive: len $recv_len");
        $swooleServer->send($fd, str_repeat("\0", $recv_len));
    }
}