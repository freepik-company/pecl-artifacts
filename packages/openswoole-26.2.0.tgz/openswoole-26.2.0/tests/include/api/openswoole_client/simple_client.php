<?php


require_once __DIR__ . "/../../../include/bootstrap.php";



suicide(5000);


$cli = new \openswoole_client(SWOOLE_SOCK_TCP, true);

/** @noinspection PhpVoidFunctionResultUsedInspection */
assert($cli->set([
    // TODO test
    // 'open_eof_check' => true,
    // 'package_eof' => "\r\n\r\n",

    // TODO
    // "socket_buffer_size" => 1,
]));

$cli->on("connect", function(openswoole_client $cli) {
    openswoole_timer_clear($cli->timeo_id);

    // TODO getSocket BUG
    // assert(is_resource($cli->getSocket()));
    /*
    $cli->getSocket();
    // Warning: openswoole_client_async::getSocket(): unable to obtain socket family Error: Bad file descriptor[9].
    $cli->getSocket();
     */


    Assert::true($cli->isConnected());
    $cli->send(RandStr::gen(1024, RandStr::ALL));
    // $cli->sendfile(__DIR__.'/test.txt');
});

$cli->on("receive", function(openswoole_client $cli, $data){
    $recv_len = strlen($data);
    debug_log("receive: len $recv_len");
    $cli->send(RandStr::gen(1024, RandStr::ALL));
    $cli->close();
    Assert::false($cli->isConnected());
});

$cli->on("error", function(openswoole_client $cli) {
    openswoole_timer_clear($cli->timeo_id);
    debug_log("error");
});

$cli->on("close", function(openswoole_client $cli) {
    openswoole_timer_clear($cli->timeo_id);
    debug_log("close");
});

$cli->connect(TCP_SERVER_HOST, TCP_SERVER_PORT);
$cli->timeo_id = openswoole_timer_after(1000, function() use($cli) {
    debug_log("connect timeout");
    $cli->close();
    Assert::false($cli->isConnected());
});
