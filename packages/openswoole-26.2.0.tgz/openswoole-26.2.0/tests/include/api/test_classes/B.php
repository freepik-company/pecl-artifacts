<?php
class SwooleTestClassB {

}