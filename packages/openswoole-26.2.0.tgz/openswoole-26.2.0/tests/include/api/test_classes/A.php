<?php
class SwooleTestClassA {

}