#!/bin/sh -e
__CURRENT__=$(pwd)
__DIR__=$(cd "$(dirname "$0")";pwd)

if [ ! -f "/.dockerenv" ]; then
    echo "" && echo "❌ This script is just for Docker env!"
    exit
fi

#-----------install build dependencies------------
apt-get update > /dev/null 2>&1 && apt-get install -y gdb > /dev/null 2>&1 || true
apt-get install -y liburing-dev 2>&1 || true
ulimit -c unlimited
echo "/tmp/core.%e.%p" > /proc/sys/kernel/core_pattern 2>/dev/null || true

#-----------compile------------
#-------print error only-------
export TERM=${TERM:-dumb}

cd "${__DIR__}" && cd ../ && \
./clear.sh > /dev/null && \
phpize --clean > /dev/null && \
phpize > /dev/null 2>&1 && \
CONFIGURE_OPTS="--enable-openssl \
--enable-http2 \
--enable-sockets \
--enable-mysqlnd \
--enable-hook-curl \
--enable-cares \
--with-postgres"

if ./configure $CONFIGURE_OPTS --enable-io-uring > /tmp/configure_iouring.log 2>&1; then
    echo "📦 io_uring enabled"
else
    echo "⚠️ io_uring not available, building without it"
    ./configure $CONFIGURE_OPTS > /dev/null
fi && \
make -j8 > /dev/null | tee /tmp/compile.log && \
(test "`cat /tmp/compile.log`"x = ""x || exit 255) && \
make install > /dev/null 2>&1 && echo "" && \
docker-php-ext-enable --ini-name zzz-docker-php-ext-openswoole.ini openswoole > /dev/null 2>&1 && \
echo "zend.max_allowed_stack_size=-1" > /usr/local/etc/php/conf.d/zzz-stack-size.ini && \
php --ri curl && \
php --ri openswoole

#-----------install xdebug for fiber context tests (disabled by default)------------
echo "" && echo "📦 Installing xdebug..." && echo ""
pecl install xdebug > /dev/null 2>&1 && \
docker-php-ext-enable xdebug > /dev/null 2>&1 && \
echo "xdebug.mode=off" >> /usr/local/etc/php/conf.d/docker-php-ext-xdebug.ini && \
echo "xdebug installed (mode=off)" || echo "⚠️ xdebug installation failed, fiber xdebug tests will be skipped"
